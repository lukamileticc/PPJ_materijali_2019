#ifndef TOKENI_H 
#define TOKENI_H 1

#define EOI 0
#define BROJ 1
#define PLUS 2
#define PUTA 3
#define OZ 4
#define ZZ 5
#define MINUS 6

#define E 7
#define EP 8
#define T 9
#define TP 10
#define F 11

#define A1 12
#define A2 13
#define A3 14

#endif



