# Program implementira automat za prepoznavanje ulaza sa parnim brojem 0
# Prelasci se odredjuju naredbama granjanja

stanje = 'P'
zavrsno ='P'
##I nacin:prelazi = {'P':['N','P'],'N':['P','N']} ako si u stanju 'P' i naidje ##nula, imas paran broj nula i treba da predjes u stanje 'N' ako si u stanju 'P' i ##naidje ti nula treba da ostanes u tom stanje, dakle u ovoj listi nulti clan je ##stanje u koje prelazis kada se dogodi nula, a prvi je stanje u koje prelazis ako ##se dogodi jedinica, kljuc recnika je stanje u kome se trenutno nalazimo, ovo moze ##jer nam je azbuka {0,1} pa je logicno a i automat je potpun

##II nacin: kljuc recnika je uredjeni par stanja u kome smo i karaktera koji citamo
##vrednost je stanje u koje prelazimo
##prelazi = {('P','0'):'N',('P','1'):'P',('N','0'):'P',('N','1'):'N'}

prelazi = {'P':{'0':'N','1':'P'}, 'N':{'0':'P','1':'N'}}
while True:
	try:
		c = input('Unesite 0 ili 1: ')
		if (c != '0' and c !='1' ):
			raise ValueError('Nije uneta ni 0 ni 1')
	except EOFError:
		break
	except ValueError as e:
		print( e)
		exit()
 	##ako biramo prvi nacin ovde treba da stoji:
	##stanje = prelazi[stanje][int(c)]

	##ako biramo drugi nacin ovde treba da stoji:
	##stanje=prelazi[(stanje,c)]
	stanje = prelazi[stanje][c]

	##klasika, bez cuvanje prelaza
	##if c == '0':
		##if stanje == 'P':
			##stanje = 'N'
		##else:	
			##stanje = 'P'
	
if stanje == zavrsno :
	print ('Rec ima paran broj nula')
else:
	print ('Rec nije prihvacena automatom')
