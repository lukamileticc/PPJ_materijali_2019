try:
	f = open("ka.txt","r")
except IOError:
	print "Nismo uspeli da otvorimo fajl"
	exit(1)

linije = f.readlines()

##print linije

def nije_komentar(l):
	return l[0]!='#' and l!='\n'
def strip(s):
	return s.strip()
linije = filter(nije_komentar, linije)
print linije
import re
azbuka = re.split(",\s*",linije[0])
azbuka = map(strip, azbuka)
print azbuka

stanja = re.split(",\s*",linije[1])
stanja = map(strip, stanja)
stanja = map(int, stanja)
print stanja

pocetno_stanje = int(linije[2].strip())
print pocetno_stanje
if pocetno_stanje not in stanja:
	print "Neispravno pocetno stanje"
	exit(1)
else:
	print "Okej pocetno stanje"

zavrsna_stanja= re.split(",\s*",linije[3])
zavrsna_stanja=map(strip, zavrsna_stanja)
zavrsna_stanja = map(int, zavrsna_stanja)
print zavrsna_stanja

for zs in zavrsna_stanja:
	if zs not in stanja:
		print "Neispravno zavrsno stanje %d" % zs
		exit(1)
	else:
		print "Okej zavrsno stanje"

prelazi = {}
##prelazi[(stanje1, slovo)]=stanje2
linije = map(strip, linije)
for i in range(4, len(linije)):
	stanje1, slovo, stanje2 = re.split("\s+",linije[i])
	stanje1 = int(stanje1)
	stanje2 = int(stanje2)
	if stanje1 not in stanja:
		print "Neispravno stanje"
		exit(1)
	else:
		print "okej stanje"
	if stanje2 not in stanja:
		print "Neispravno stanje"
		exit(1)
	else:
		print "okej stanje"
	if slovo not in azbuka:
		print "Neispravno stanje"
		exit(1)
	else:
		print "okej stanje"
	if (stanje1, slovo) in prelazi:
		print "Automat nije dka"
	else:
		prelazi[(stanje1,slovo)]=stanje2	
	print stanje1, slovo, stanje2

print prelazi
import sys
rec = sys.stdin.readline()
rec = rec.strip()
print rec

tekuce_stanje = pocetno_stanje
for karakter in rec:
	if (tekuce_stanje,karakter) not in prelazi:
		print "greska,ne prihvatam rec"
		exit(1)
	else:
		tekuce_stanje = prelazi[(tekuce_stanje, karakter)]


if tekuce_stanje in zavrsna_stanja:
	print "Automat prihvata rec"
else:
	print "Automat ne prihvata rec"

