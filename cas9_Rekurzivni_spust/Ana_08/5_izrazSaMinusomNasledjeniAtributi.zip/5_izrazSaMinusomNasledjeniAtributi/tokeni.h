#ifndef TOKENI_H 
#define TOKENI_H 1

/* tokeni */

#define PLUS 1
#define PUTA 2
#define BROJ 3
#define OZ   4
#define ZZ   5
#define MINUS 6
#define PODELJENO 7
#define EOI 0


#endif
