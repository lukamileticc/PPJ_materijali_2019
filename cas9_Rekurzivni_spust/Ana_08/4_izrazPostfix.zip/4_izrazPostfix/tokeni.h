#ifndef _TOKENI_H_
#define _TOKENI_H_

#define EOI 0
#define BROJ 1
#define OZ 2
#define ZZ 3
#define PLUS 4
#define PUTA 5

#endif