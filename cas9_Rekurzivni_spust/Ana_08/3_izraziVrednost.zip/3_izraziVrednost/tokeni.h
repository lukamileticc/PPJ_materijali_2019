#ifndef _TOKENI_H_
#define TOKENI_H_

#define BROJ 1
#define PLUS 2
#define PUTA 3
#define LZ 4
#define DZ 5
#define EOI 0

#endif