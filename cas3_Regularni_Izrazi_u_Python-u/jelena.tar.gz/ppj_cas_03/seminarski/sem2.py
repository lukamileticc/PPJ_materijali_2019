import re, os, sys

homedir = 'seminarski_radovi'
studenti ={}
indeksi = open(homedir+'/indeksi','r')
for linija in indeksi.readlines():
	if linija[-1]=='\n':
		linija = linija[0:-1]
	info = re.split(r',\s*',linija)
        print info
	studenti[info[0]]=info[1]

print studenti
re_dir = re.compile(r'^m[mnvilr]\d{5}$')
re_file = re.compile(r'^(\d+)\.(java|c|cpp|pas)$')

max_br_zad = 0
zadaci ={}
#predali=[]

for f in os.listdir(homedir):
	stud_dir = os.path.join(homedir,f)
        print stud_dir
	m = re_dir.match(f)
        if os.path.isdir(stud_dir) and m is not None and m.group() in studenti:
		stud_indeks = m.group()
                print stud_indeks
		#predali.append(stud_indeks)
		for sf in os.listdir(stud_dir):
			zadatak_path = os.path.join(stud_dir, sf)
			m = re_file.match(sf)
			if os.path.isfile(zadatak_path) and m is not None:
				zadatak = int(m.group(1))
				if zadatak>max_br_zad:
					max_br_zad = zadatak
				kljuc = stud_indeks + " " + m.group(1)
				zadaci[kljuc]=m.group(2)

for indeks, ime in studenti.iteritems():
	print "\n" + ime + " "
	for i in range(1, max_br_zad+1):
		kljuc = indeks + " "+str(i)
                if kljuc not in zadaci:
			print "\t-"
                else:
			print "\t" + zadaci[kljuc]

	



