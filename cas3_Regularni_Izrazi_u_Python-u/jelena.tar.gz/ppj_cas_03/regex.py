#!/usr/bin/python

import sys, re, os

recenica = "Danas je lep dan sunce sija je divan"
#m = re.match(r"(?i)(\w+\s*)", recenica)
m = re.search(r"d[a-z]+",recenica)

m = re.findall(r"d[a-z]+",recenica)
for x in m:
	print(x)
        
