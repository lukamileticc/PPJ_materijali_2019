import sys

try:
	f = open("podaci.xml","r")
except IOError:
	print "Neuspel citanje fajla"
	exit(1)	
sadrzaj = f.read()

trazim_naziv = False
trazim_opis = False
trazim_verziju = False
trazim_repozitorijum = False
trazim_veb = False
trazim_sve = False

ime_paketa = ''

if len(sys.argv) <2 :
	print "Neispravan poziv"
	exit(1)

if len(sys.argv)==2 :
	trazim_sve = True
else:
	for arg in sys.argv[1:]:
		if arg == "-v":
			trazim_verziju = True
		elif arg == "-w":
			trazim_veb = True
		elif arg == "-r":
			trazim_repozitorijum = True
		elif arg == "-o":
			trazim_opis = True
		else:
			ime_paketa = arg
	if ime_paketa == '':
		print "Neispravan poziv"
		exit(1)
import re

pattern1 = re.compile(r'<paket\s+id\s*="(\d+)"\s*>',re.I)
pattern2 = re.compile(r'<naziv>\s*(\w+)\s*</naziv>',re.I)
pattern3 = re.compile(r'<verzija>\s*(\d+)\.(\d+)\.(\d+)\s*</verzija>',re.I)
pattern4 = re.compile(r'<repo>\s*((github)|(gitlab)|(bitbucket))\s*</repo>',re.I)
pattern5 = re.compile(r'<veb>\s*((www\.)?(\w+\.)+((org)|(com)))\s*</veb>',re.I)
pattern6 = re.compile(r'<opis>\s*([^<]+)\s*</opis>',re.I)

mapa = {}
for m in pattern1.finditer(sadrzaj):
	m_next = pattern1.search(sadrzaj, m.end())
	if m_next is None:
		tmp = len(sadrzaj)
	else:
		tmp = m_next.start()

	i = pattern2.search(sadrzaj, m.end(),tmp)
	if i is not None:
		naziv = i.group(1)
	else:
		naziv = "neispravan"
	i = pattern3.search(sadrzaj, m.end(),tmp)
	if i is not None:
		verzija = i.group(1)+"."+i.group(2)+"."+i.group(3)
	else:
		naziv = "neispravan"
	i = pattern4.search(sadrzaj, m.end(), tmp)
	if i is not None:
		repo = i.group(1)
	else:
		naziv = "neispravan"
	i = pattern5.search(sadrzaj, m.end(),tmp)
	if i is not None:
		veb = i.group(1)
	else:
		naziv = "neispravan"
	i = pattern6.search(sadrzaj, m.end(), tmp)
	if i is not None:
		opis = i.group(1)
	else:
		naziv = "neispravan"
	mapa[naziv]=(verzija, repo,veb,opis)

print mapa
del mapa["neispravan"]
print mapa

if trazim_sve:
	keys= mapa.keys()
	print keys
	keys.sort()
	for k in keys:
		print '[{}] v{} {}\n{}\n{}\n'.format(k, mapa[k][0],mapa[k][1],mapa[k][2],mapa[k][3])
else:
	if trazim_naziv:
		print ime_paketa
	if trazim_opis:
		print mapa[ime_paketa][3]
	if trazim_veb:
		print mapa[ime_paketa][2]


